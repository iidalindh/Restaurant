export default interface IBooking {
    _id?: string,
    date: string
    time: number
    numberOfGuests: number
    customerName: string
    customerEmail: string
}
