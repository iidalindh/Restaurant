export const colorScheme = {
    main: "#004CBF"

}